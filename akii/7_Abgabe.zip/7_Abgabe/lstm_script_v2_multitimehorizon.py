# %% [markdown]
# Projekt LSTM

# importieren notwendiger bibliotheken
import pandas as pd # Datenverarbeitung     
import numpy as np  # Mathe
import matplotlib.pyplot as plt #   Visualisierung


# Imports Sklearn
from sklearn.model_selection import ParameterGrid
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# Imports Deep Learning Pytorch
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

# Ausblenden von Warnungen um prints besser zu lesen
import warnings
warnings.filterwarnings('ignore')

# Einbinden von wandb
import wandb

# eigene Bibliothek für Plots
from molib import * 
plot = Plot(storage_path='1_plots/')


#####################################
if 1:
    pv_power1 = pd.read_csv("0_data/raw/611_PowerEl_PV1AC.csv", index_col=0, parse_dates=True)
    pv_power2 = pd.read_csv("0_data/raw/616_PowerEl_PV2AC.csv", index_col=0, parse_dates=True)
    # ebh fehlt
    weather_data = pd.read_csv('0_data/raw/solcast_PT5M.csv', index_col='period_end', parse_dates=True, usecols=['ghi','dni','dhi','air_temp','zenith','azimuth','cloud_opacity','period_end'])
    # period end zu perod begin verschieben
    weather_data.index = weather_data.index.shift(-1, freq='5T')

    # merge von pv_power1 und pv_power2
    pv_power = pd.merge(pv_power1, pv_power2, left_index=True, right_index=True)
    # merge von pv_power und weather_data
    pv_power = pd.merge(pv_power, weather_data, left_index=True, right_index=True)

    historic_data = pv_power.copy()
    # Umbennen der Pv leistungs spalten
    historic_data.rename(columns={'611_PowerEl_PV1AC':'pv_power1', '616_PowerEl_PV2AC':'pv_power2'}, inplace=True)
    historic_data.to_csv('0_data/raw/merged_raw_data.csv')
else:
    historic_data = pd.read_csv('0_data/raw/merged_raw_data.csv', index_col=0, parse_dates=True)

# Interval anpassen
historic_data = historic_data.resample('60min').mean()

# Zeitraum auswählen
historic_data = historic_data['2020-01-01':'2023-01-31']


### Features erweitern mit Zeitverschiebungen
def shift_and_merge(df, n_shifts):
    full_data = df.copy()
    
    # Verschieben der Daten in die Zukunft und in die Vergangenheit
    for i in range(1, n_shifts + 1):
        shifted_future = df.shift(periods=-i)
        shifted_past = df.shift(periods=i)
        
        # Spalten umbenennen
        shifted_future.columns = [f"{column}_n+{i}" for column in shifted_future.columns]
        shifted_past.columns = [f"{column}_n-{i}" for column in shifted_past.columns]
        
        # Daten mergen
        full_data[shifted_future.columns] = shifted_future
        full_data[shifted_past.columns] = shifted_past
    
    return full_data

time_shift = 27
full_data = shift_and_merge(historic_data, time_shift)

# %%

# Funktion zum Generieren der Feature-Namen
def generate_feature_names(base_features, n_values, future=True, historic=False):
    feature_names = base_features.copy()
    for n in range(1, n_values + 1):
        for feature in base_features:
            if future and feature != 'pv_power1' and feature != 'pv_power2':
                feature_names.append(f'{feature}_n+{n}')
            if historic:
                # raus da er es theoretisch über das lstm window lernen kann
                pass
                #feature_names.append(f'{feature}_n-{n}')
            if feature != 'pv_power1' and feature != 'pv_power2':
                pass
                #feature_names.append(f'{feature}')
    return feature_names

# Definieren der Basis-Features
base_features = ['pv_power1', 'pv_power2', 'air_temp', 'azimuth', 'cloud_opacity', 'dhi', 'dni', 'ghi', 'zenith']
								
# Generieren der Feature-Namen
future_and_historic_values = 27 # beachte historische Werte werden nicht verwendet
future_and_historic_features = generate_feature_names(base_features, future_and_historic_values, future=True, historic=True)

# Festlegen der Zielvariable für die Vorhersage
# Ziel Variable ist der +n wert von pv_power2
prediction_target = 'pv_power2_n+1'

# Namen der Spalten, in denen NaN-Werte und Null-Werte überprüft werden sollen
columns_to_check_nan = future_and_historic_features.copy()
columns_to_check_nan.append(prediction_target)


# Eigene Klasse für die Pipeline zum Entfernen von Zeilen mit NaN-Werten,  Null-Werten und negativen Werten
class DropRowsWithNaNAndZero(BaseEstimator, TransformerMixin):
    def __init__(self, columns_to_check_nan=None, columns_to_check_zero=None, columns_to_check_negative=None):
        self.columns_to_check_nan = columns_to_check_nan
        self.columns_to_check_zero = columns_to_check_zero
        self.columns_to_check_negative = columns_to_check_negative

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        # Kopie des DataFrames erstellen, um das Original nicht zu ändern
        X_copy = X.copy()

        if self.columns_to_check_nan is not None:
            # Zeilen mit NaN-Werten in den angegebenen Spalten entfernen
            X_copy.dropna(subset=self.columns_to_check_nan, inplace=True)
        
        if self.columns_to_check_zero is not None:
            # Zeilen mit Null-Werten in den angegebenen Spalten entfernen
            for col in self.columns_to_check_zero:
                pass
                #X_copy = X_copy[X_copy[col] != 0]
                
        if self.columns_to_check_negative is not None:
            # Zeilen mit positen-Werten in den angegebenen Spalten markieren 
            # dadurch werden negative auf 0 gesetzt
            for col in self.columns_to_check_negative:
                X_copy[X_copy[col] < 0] = 0
            pass

        return X_copy

# Namen der Spalten, in denen NaN-Werte und Null-Werte überprüft werden sollen
columns_to_check_zero = []#['pv_power2', 'pv_power1']
columns_to_check_negative = []
for featere in future_and_historic_features:
    if 'pv_power' in featere:
        columns_to_check_negative.append(featere)

# 1. Pipeline mit Dataframes
# Erstellen der Pipeline
pre_processor = Pipeline([
    ('data_cleaning', DropRowsWithNaNAndZero(columns_to_check_nan, columns_to_check_zero, columns_to_check_negative)),
])
full_data = pre_processor.transform(full_data)


# Erstellen verschiedener feature sets
feature_set0 = future_and_historic_features


dict_feature_sets = {
    'feature_set0': feature_set0,
}


torch.cuda.is_available() # True wenn GPU verfügbar ist
print(feature_set0)

# Daten übergeben
data_set = full_data


# Hyperparameter Grid

param_grid = {
    'hidden_size': [300],
    'num_layers': [2],
    'num_epochs': [300],
    'learning_rate': [0.0001],
    'window': [24, 12, 48],
    'horrizon': [24],
    'batch_size': [4, 8],
    'feature_set': ['feature_set0'],
    'prediction_column': [prediction_target],# ['pv_power2']
}


# Erstellen Sie das Grid
grid = ParameterGrid(param_grid)

for params in grid:
    # Start eines neuen Runs für wandb 
    run = wandb.init(# set the wandb project where this run will be logged
    project="LSTM-Project",
    name=f"lstm_model_{params['prediction_column']}_Learningrate_{params['learning_rate']}_Window_{params['window']}_Layer_{params['num_layers']}_Epochen_{params['num_epochs']}_hidden_size_{params['hidden_size']}_feature_set_{params['feature_set']}_prediction_column_{params['prediction_column']}",
    # track hyperparameters and run metadata
    config=params
    )
    
    print(params)
    
    # Auswählen der Zielvariablen und der benutzten Features
    # Spalten für die Vorhersage und die Features
    prediction_column = params['prediction_column']
    feature_set = params['feature_set']
    x_columns = dict_feature_sets[feature_set]
    y_columns = [prediction_column]
    
    
    # Übergabe der Hyperparameter
    hidden_size = params['hidden_size'] # Anzahl der Neuronen in der LSTM-Schicht
    num_layers = params['num_layers'] #  Anzahl der LSTM-Schichten
    num_epochs = params['num_epochs']  # Anzahl der Epochen
    learning_rate = params['learning_rate']  # Lernrate
    
    # z.B. bis n+3 vorhersagen
    horrizon = params['horrizon'] # Anzahl der Werte die vorhergesagt werden sollen
    # n-6 zur Vorhersage verwenden
    window = params['window'] # Anzahl der Vergangenheits Werte die für die Vorhersage verwendet werden sollen
    
    # horizont( z.B von n-6 bis n-1) + window (z.B. n+1 bis n+3) + 1 (n) = sequence_length
    sequence_length = horrizon + window +1 # Länge einer Sequenz
    #sequence_length = params['sequence_length']  # Länge einer gesamten Sequenz
    
    
    
    # Input und Output Größe des Modells festlegen
    input_size = len(x_columns) # Alle Spalten außer den prognostizierten Wert
 
    
    
    # Daten in Sequenzen aufteilen
    sequences = []
    scaler_x = MinMaxScaler(feature_range=(0, 1)).fit(data_set[x_columns])
    scaler_y = MinMaxScaler(feature_range=(0, 1)).fit(data_set[y_columns])



    # Die Schleife teilt die Daten in Sequenzen auf
    # eine Sequenz besteht aus z.B. den 24 vorherigen Werten und dem nächsten Wert
    # die Sprünge sind jeweils von z.B.:
    # x:1 bis 24 prognositierziert y:z.b. 25-28
    # x:2 bis 25 prognostiziert y:26-29
    # x:3 bis 26 prognostiziert y:27-30
    # ... 
    print(len(data_set))
    # Range Maximum berechnen: durch test am ende ermittelt differnz von 2 bei horrizon von 3 festgestellt
    for i in range(len(data_set) - (sequence_length)):
        X = data_set[x_columns].iloc[i:i + window + 1, :] # i - i + sequence_length sind die Werte die für die Vorhersage verwendet werden
        X = scaler_x.transform(X)  # Daten skalieren
        y = data_set[y_columns].iloc[i + window+1:i + window+horrizon+1]  # Annahme: Die Ausgabe ist die erste Spalte
        y = scaler_y.transform(y)  
        sequences.append((X, y))


    # Aufteilen in Trainings- und Testdaten
    train_size = int(len(sequences) * 0.8)
    train_data, test_data = sequences[:train_size], sequences[train_size:]

    # Anzahl der Zielvariablen = Anzahl der Ausgabeneuronen = Horrizon
    output_size = horrizon

    # LSTM-Modell definieren
    class LSTM(nn.Module):
        def __init__(self, input_size, hidden_size, num_layers, output_size):
            super(LSTM, self).__init__()
            # Anzahl der neuronale Netze in der LSTM-Schicht
            self.hidden_size = hidden_size
            # Anzahl der LSTM-Schichten
            self.num_layers = num_layers
            # LSTM-Schicht
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=False)
            # Die Ausgabe der LSTM-Schicht wird an eine lineare Schicht weitergegeben
            self.fc = nn.Linear(hidden_size, output_size)
            self.hidden = None

        def forward(self, x):
            # hidden state durch reichen führt zu fehler ?
            if 1:# self.hidden == None:
                # multiplizieren der Anzahl der LSTM-Schichten mit 2, da bidirektional
                # Initialisieren der versteckten Zustände, dieser beinhaltet die Information über die vorherigen Zustände
                h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device).requires_grad_()
                # Cell state initialisieren, dieser beinhaltet die Information über die vorherigen Zustände
                c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device).requires_grad_()
                hn, cn = h0, c0
            else:
                hn, cn = self.hidden

            # Forward Propagation, Berechnung des LSTM layers
            out, hidden = self.lstm(x, (hn, cn))
            

            # Ausgabe in der linearen Schicht berechnen
            out = self.fc(out[:, -1, :])
            # (batch_size, sequence_length)
            self.hidden = hidden
            return out

    # Modell, Loss-Funktion und Optimizer initialisieren
    # Gerätekonfiguration, bestimmt ob das Modell auf der CPU oder GPU ausgeführt wird
    device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')
    print("Berechnungen laufen auf: ", device)
    # Modell mit Hyperparametern initialisieren
    model = LSTM(input_size, hidden_size, num_layers, output_size).to(device)
    # Loss-Funktion initialisieren, 
    # hier sind andere Funktionen denkbar wie z.B. CrossEntropyLoss, NLLLoss oder PoissonNLLLoss
    criterion = nn.MSELoss()
    # Optimizer initialisieren, hier sind andere Optimizer denkbar wie z.B. SGD oder Adamax
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    
    # Decay Rate definieren verkleinert die Lernrate nach jeder Epoche
    decay_rate = 0.95
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=decay_rate)

    
    # Early stopping callback
    early_stop_counter = 0
    
    
    # Verwendung Batch
    # Convert sequences to TensorDataset
    train_data = TensorDataset(torch.tensor([x for x, y in train_data]).float(), torch.tensor([y for x, y in train_data]).squeeze(-1).float())

    # Define batch size
    batch_size = params['batch_size'] 

    # Create DataLoaders
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
 
    # Training des Modells Erfolg über die Anzahl der Epochen
    # Eine Epoche ist ein Durchlauf über den gesamten Datensatz
    # In jeder Epoche wird das Modell mit den Trainingsdaten trainiert
    # Diese teilen sich in Sequenzen auf, die in der Variable train_data gespeichert sind
    # Traing erfolgt jeweils mit der Windows size + 1 und die Vorhersage ist der Horizon
    for epoch in range(num_epochs):
        for X_batch, y_batch in train_loader:
        #for X, y in train_data:
            # Move batch to device
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
                
            
            # Die Daten in Tensoren konvertieren und auf das Gerät laden
            #X = torch.from_numpy(X).float().unsqueeze(0).to(device)
            #y = torch.tensor(y).float().unsqueeze(0).to(device)

            # Optimizer zurücksetzen
            optimizer.zero_grad()
            # Vorhersage berechnen
            output = model(X_batch)
            # .squeeze(-1) entfernt die letzte Dimension in den Traingsdaten, da num features nicht benötigt wird, da Ausgabe immer nur ein 'Spaltenvektor' ist
            #print(output.size()) # (batch_size, sequence_length)
            #print(y_batch.size()) # (batch_size, sequence_length, num_features)
            
            # Loss berechnen
            loss = criterion(output, y_batch)
            # Backpropagation
            loss.backward()
            
            # Gewichte aktualisieren
            optimizer.step()

            wandb.log({"loss": loss})
            lr = optimizer.param_groups[0]['lr']
            wandb.log({"learning_rate": lr})
            
        # rmse aus loss berechnen
        y_readable = scaler_y.inverse_transform(y_batch.cpu().detach().numpy().reshape(-1, 1))
        output_readable = scaler_y.inverse_transform(output.cpu().detach().numpy().reshape(-1, 1))
        
        #print(y_readable)
        #print(output_readable)
        if epoch == 0:
            old_rmse = 0
        else:
            old_rmse = rmse
        rmse = mean_squared_error(y_true=y_readable,y_pred=output_readable, squared=False)#torch.sqrt(criterion(output_readable, y_readable))
        
        difference = abs(old_rmse - rmse)
        # Early stopping 
        if difference < 100:
            print(early_stop_counter)
            early_stop_counter =early_stop_counter+1
            if early_stop_counter == 3:
                print("Early stopping")
                num_epochs = epoch
                break
        else:
            early_stop_counter = 0
            
        # Am Ende jeder Epoche
        scheduler.step()
                
        # Loss ausgeben
        if (epoch + 1) % 1 == 0:
            print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.7f}, RMSE: {rmse:.2f}')


    # Test des Modells
    # Modell in den Evaluationsmodus versetzen
    model.eval()
    real_values = []
    predictions = []
    # Vorhersage ohne Berechnung der Gradienten
    with torch.no_grad():
        # Schleife mit höherer Schrittegröße, sodass y-Werte für die Vorhersage nicht überlappen
        # also prediction y+1, y+2, y+3 dann drei schritte weiter
        for i in range(0, len(test_data), horrizon):
            X, y = test_data[i]
            # Eine Sequenz aus den Testdaten auswählen
            # unsqueeze(0) fügt eine Dimension hinzu, da das Modell immer eine Batch-Größe erwartet
            # to(device) lädt die Daten auf das Gerät
            # LSTM-Modell erwartet eine Eingabe mit der Form (batch_size, sequence_length, input_size)
            test_input = torch.from_numpy(X).float().unsqueeze(0).to(device)
            # Einen Wert vorhersagen
            prediction = model(test_input).cpu().numpy().flatten()
            prediction = scaler_y.inverse_transform(prediction.reshape(-1, 1))
            y = scaler_y.inverse_transform(y.reshape(-1, 1))
            
            for pred_value, real_value in zip(prediction, y):
                predictions.append(pred_value[0])
                real_values.append(real_value[0])
            
        
    # die letzten Predcitions und real_values entfernen, da diese nicht mehr vollständig sind
    predictions = predictions[:len(data_set.index[train_size-1:len(sequences)-1])]
    real_values = real_values[:len(data_set.index[train_size-1:len(sequences)-1])]
    
    
    result = pd.DataFrame()
    result['real_values'] = real_values
    result['predictions'] = predictions
    (result)



    # %%
    # Index des Trainingdatensatzes für die Visualisierung
    print(len(result.index))
    print(len(data_set.index[train_size-1:len(sequences)-1]))
    result.index = data_set.index[train_size:len(sequences)]
    rmse = mean_squared_error(result['real_values'], result['predictions'], squared=False)

    print(rmse)
    parameter_str = f'rmse_{rmse}, Learningrate_{learning_rate}, Horrizon_{horrizon}, Window_{window}, Layer_{num_layers}, epoch_{num_epochs}, hidden_{hidden_size}, feature_{feature_set}, batch_{batch_size}, pc_{prediction_column}, fh_{future_and_historic_values}, ts_{time_shift}'
    #parameter_str = f'rmse_{rmse}, Learningrate_{learning_rate}, Horrizon_{horrizon}, Window_{window}, Layer_{num_layers}, Epochen_{num_epochs}, hidden_size_{hidden_size}, feature_set_{feature_set}, batch_size{batch_size}, prediction_column_{prediction_column}'
    plot.timeseries(result, stacked=False, save_on_disk=True, plot_label=f'MultitimeHorizon 15min {parameter_str}')
    
    torch.save(model, f'3_models/MultitimeHorizon 15min {parameter_str}.pt')
    #plot.timeseries(df.loc[result.index], stacked=False)
    # Beeenden des Runs von wandb
    run.finish()


